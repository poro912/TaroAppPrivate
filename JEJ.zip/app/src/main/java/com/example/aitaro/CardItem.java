package com.example.aitaro;

public class CardItem {
    private int imageResource;

    public CardItem(int imageResource) {
        this.imageResource = imageResource;
    }

    public int getImageResource() {
        return imageResource;
    }
}
