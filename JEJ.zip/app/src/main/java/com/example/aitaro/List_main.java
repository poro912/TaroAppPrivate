package com.example.aitaro;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class List_main extends AppCompatActivity {

        private ListView list;

        @Override
        protected void onCreate(Bundle savedinstanceState){ //생명주기
            super.onCreate(savedinstanceState);
            setContentView(R.layout.main_list);

            list = (ListView)findViewById(R.id.list);

        List<String> date = new ArrayList<>();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, date);
        list.setAdapter(adapter);

        date.add("원 카드 스프레드");
        date.add("쓰리 카드 스프레드");
        date.add("켈트 십자가 스프레드");
        date.add("생며의 나무 스프레드");
        date.add("말 발굽 스프레드");
        date.add("보름달 스프레드");
        adapter.notifyDataSetChanged();

        list.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long id) {
                       //String item = String.valueOf(parent.getitemAtPosition(i));
                       // Toast.makeText(MainActivity.this.itme. Toast.LENGTH_SHORT). show();

                    }
                }

        );

        }



}
